#include <stdio.h>


int cross_correlation_asm_full(int* arr_1, int size_1, int* arr_2, int size_2, int* output, int output_size){

	int* a = arr_1;
	int* b = arr_2;

	int as = size_1;
	int bs = size_2;
	int os = output_size;
	int f1;
	
	int f2;
	
	int total;
	int i;
	int j;
	int t;
	int k;
	int c2;
	int c1;
	int c22;
	int sum;
	int count = -1;

	for (i=0; i<as; i++){
		count = count + 1;
		total = 0;
		f1 = i;
		f2 = bs-1;
		for(j=0; j<=i; j++){
			sum = a[f1] * b[f2];
			total = total + sum;
			if(f2==0) break;
			if(f1!=0) f1 = f1 - 1;
			if(f2!=0) f2 = f2 - 1;
		}
		output[count] = total;
		if(i == (as - 1)){
			k = bs - 2;
			c2 = bs - 2;
			c22 = bs - 2;
			while(k>=0){
				count = count + 1;
				c1 = as - 1;
				total = 0;
				for(t=0; t<(c2+1); t++){
					if(c1==0){
						sum = a[c1] * b[c2];
						total = total + sum;
						c1 = c1 - 1;
						if(c2!=0) c2 = c2 - 1;
						break;
					}
					sum = a[c1] * b[c2];
					total = total + sum;
					c1 = c1 - 1;
					if(c2!=0){
					    c2 = c2 - 1;
					    if(c2==0&&c1!=(as-1)){
					    sum = a[c1] * b[c2];
					    total = total + sum;
				    	c1 = c1 - 1; 
				    	break;
					}
					    
					} 
					

				}
				output[count] = total;
				c22 = c22 - 1;
				c2 = c22;
				k = k - 1;


			}


		}
	}

	int nonzero = 0;
	int q;

	for(q=0; q<os;q++){
		if(output[q]==0) nonzero++;
	}

	return nonzero;

}

