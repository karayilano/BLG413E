#include <stdio.h>
int main()
{
	int a[] = {7};
	int b[] = {19, 11, 0};
	int output[3];

	int as = 1;
	int f1;
	int bs = 3;
	int f2;
	int os = 3;
	int total;
	int i;
	int j;
	int t;
	int k;
	int c2;
	int c1;
	int c22;
	int sum;
	int count = -1;

	for (i=0; i<as; i++){
		count = count + 1;
		total = 0;
		f1 = i;
		f2 = bs-1;
		for(j=0; j<=i; j++){
			sum = a[f1] * b[f2];
			total = total + sum;
			if(f2==0) break;
			if(f1!=0) f1 = f1 - 1;
			if(f2!=0) f2 = f2 - 1;
		}
		output[count] = total;
		if(i == (as - 1)){
			k = bs - 2;
			c2 = bs - 2;
			c22 = bs - 2;
			while(k>=0){
				count = count + 1;
				c1 = as - 1;
				total = 0;
				for(t=0; t<(c2+1); t++){
					if(c1==0){
						sum = a[c1] * b[c2];
						total = total + sum;
						c1 = c1 - 1;
						if(c2!=0) c2 = c2 - 1;
						break;
					}
					sum = a[c1] * b[c2];
					total = total + sum;
					c1 = c1 - 1;
					if(c2!=0){
					    c2 = c2 - 1;
					    if(c2==0&&c1!=(as-1)){
					    sum = a[c1] * b[c2];
					    total = total + sum;
				    	c1 = c1 - 1; 
				    	break;
					}
					    
					} 
					

				}
				output[count] = total;
				c22 = c22 - 1;
				c2 = c22;
				k = k - 1;


			}


		}
	}

	for(i=0;i<os;i++){
		printf("%d ", output[i]);
	}


    return 0;
}
