#include <linux/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define IOC_MAGIC 'm'

#define MMIND_REMAINING _IOR(IOC_MAGIC, 1, int32_t)
#define MMIND_ENDGAME _IO(IOC_MAGIC, 2)
#define MMIND_NEWGAME _IOW(IOC_MAGIC, 3, int32_t*)

int main()
{
	
	int selection;
	int fd;
	int newSecret = 3456;
	int32_t value, number;
	int remaining;
	fd = open("/dev/mastermind", O_RDWR);
	if(fd < 0){
		printf("Failed to open device\n");
		return 0;
	}
	while (1){
		printf("\n\n*******************************************\n\n");
		printf("1-Display remaining guesses\n");
		printf("2-End game\n");
		printf("3-New game\n\n");
		printf("Please make a selection (-1 to quit): ");
		scanf("%d", &selection);
		if(selection == -1){
			break;
		}
		else if(selection == 1){
			ioctl(fd, MMIND_REMAINING, (int32_t*) &remaining);
			printf("Remaining guesses: %d\n", remaining);
		}
		else if(selection == 2){
			printf("Game ended.\n");
			ioctl(fd, MMIND_ENDGAME);
		}
		else if(selection == 3){
			printf("Enter secret number to start new game: ");
			scanf("%d", &newSecret);
			if(newSecret < 10000 && newSecret > 999){
			ioctl(fd, MMIND_NEWGAME, (int32_t*) &newSecret);
			}
			else{
				printf("Secret number should be 4 digits!\n");
			}
		}
		else{
			printf("Wrong selection!\n");
		}
		printf("\n*******************************************\n\n");
	}
	close(fd);
	return 0;
}
