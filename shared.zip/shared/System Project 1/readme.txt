Firstly we need to enter the directory of program in terminal.
In our case it is "cd Desktop/Char_Device/".
To get superuser privilages we type "sudo su".
Then by typing "make" we compile our program.
After, we insert device by typing "insmod mastermind.ko mmind_number="1234" mmind_max_guesses=20 ".
mmind_number and mmind_max_guesses are optional parameters.
Now we can see our device under /dev folder.
If we want to remove device we can type "rmmod mastermind.ko".
Now we are able to play the game.
We can write to the device by typing "echo "2345" > /dev/mastermind".
And we can see our guess history and results by typing "cat /dev/mastermind".
When we reach max guess count program will not let us enter anymore guesses.

For testing ioctl commands we can enter the directory of ioctal.c file.
In our case it is "cd Desktop/Ioctl\ Test/".
Than we compile our file by typing "gcc ioctl.c -o ioctl.o".
We also need superuser privilages, we can get it by typing "sudo su".
To run our test program we type "./ioctl.o".
Our example program will guide the user.


Important Note:  ioctal.c file takes newgame's secret number as integer. Input should be without quotes. 
For example 4283 instead of "4283".
