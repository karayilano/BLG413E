#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>
#include <linux/kernel.h>
#include <linux/ioctl.h>

#define DEVICE_MAJOR 0
#define DEVICE_MINOR 0

#define IOC_MAGIC 'm'

#define MMIND_REMAINING _IOR(IOC_MAGIC, 1, int32_t)
#define MMIND_ENDGAME _IO(IOC_MAGIC, 2)
#define MMIND_NEWGAME _IOW(IOC_MAGIC, 3, int32_t*)

MODULE_LICENSE("Dual BSD/GPL");

dev_t devNo = 0;
static struct class *cl;
static struct cdev dev;

static char lines[256][16];
static int currentLine = 0;

static char *mmind_number = "1111";
module_param(mmind_number, charp, S_IRUGO|S_IWUSR);

static int mmind_max_guesses=10;
module_param(mmind_max_guesses,int,0660);

static int currentGuess = 0;

static int openDevice(struct inode *,struct file *);
static int closeDevice(struct inode *,struct file *);
static ssize_t readDevice(struct file *,char *,size_t, loff_t *);
static ssize_t writeDevice(struct file *,const char *,size_t, loff_t *);
static long ioctlDevice(struct file *, unsigned int, unsigned long);
static void endGame(void);

static int isNewGame = 0;
static char mmind_newNumber[5];

static struct file_operations fops=
{
	.read = readDevice,
	.open = openDevice,
	.write = writeDevice,
	.release = closeDevice,
	.unlocked_ioctl = ioctlDevice,
};

int __init mm_init(void)
{
	int i;
	if(alloc_chrdev_region(&devNo, 0, 1, "mm0") < 0)
	{
		printk(KERN_ALERT "Can not load device...\n");
		return -1;
	}
	cdev_init(&dev, &fops);
	if (cdev_add(&dev, devNo, 1) < 0)
	{
		unregister_chrdev_region(devNo, 1);
		printk(KERN_ALERT "Can not load device...\n");
		return -1;
	}	
	if ((cl = class_create(THIS_MODULE, "mastermind_class")) == NULL)
	{
		unregister_chrdev_region(devNo, 1);
		printk(KERN_ALERT "Can not load device...\n");
		return -1;
	}
	if (device_create(cl, NULL, devNo, NULL, "mastermind") == NULL)
	{
		class_destroy(cl);
		unregister_chrdev_region(devNo, 1);
		printk(KERN_ALERT "Can not load device...\n");
		return -1;
	}
	printk(KERN_ALERT "Device successfully loaded...\n");
	
	for(i = 0; i < 4; i++)
	{
		mmind_newNumber[i] = mmind_number[i];
	}
	printk(KERN_ALERT "Number: %s\n", mmind_newNumber);
	
	return 0;

}

void __exit mm_exit(void)
{
	device_destroy(cl, devNo);
	class_destroy(cl);
    cdev_del(&dev);
    unregister_chrdev_region(devNo, 1);
}

static int openDevice(struct inode *inod,struct file *fil)
{
	printk(KERN_WARNING "Device opened...\n");
	return 0;
}



static ssize_t readDevice(struct file *filp,char *buff,size_t len,loff_t *off)
{
	
    return simple_read_from_buffer(buff, len, off, *lines, currentLine * 16);

}

static ssize_t writeDevice(struct file *filp,const char *buff,size_t len,loff_t *off)
{
	
	char tmp;
	int i,j, mmCount, guessCount, minCount;
	int plus = 0, minus = 0;
	char newLine[16];
	char guessNumber[4];
	int n;
	
	printk(KERN_WARNING "Length: %d", len);
	
	if(currentGuess >= mmind_max_guesses) return len;
	if(len !=5){
		printk(KERN_WARNING "Input should be 4 digits!\n");
		return len;
	}
	for(i = 0; i < 4; i++)
	{
		if(!(buff[i] >= '0') || !(buff[i] <= '9'))
		{
			printk(KERN_WARNING "Input should include numbers only!\n");
			return len;
		}
	}
	currentGuess++;
	
	for(i = 0; i < 4; i++)
	{
		if(mmind_newNumber[i] == buff[i])
		{
			plus++;
		}
	}
	tmp = '0';
	for(i = 0; i < 10; i++)
	{
		mmCount = 0;
		guessCount = 0;
		for(j = 0; j < 4; j++)
		{
			if(mmind_newNumber[j] == tmp)
			{
				mmCount++;
			}
			if(buff[j] == tmp)
			{
				guessCount++;
			}
		}
		if (mmCount < guessCount) minCount = mmCount;
		else minCount = guessCount;
		minus += minCount;
		tmp++;
	}
	minus -= plus;
	snprintf(newLine, 16, "xxxx %d+ %d- 0000", plus, minus);
	newLine[15] = '\n';
	for(i = 0; i < 4; i++)
	{
		newLine[i] = buff[i];
	}
	
	n = snprintf(guessNumber, 4, "%d", currentGuess);
	j = 0;
	for(i = 15 - n; i < 15; i++)
	{
		newLine[i] = guessNumber[j];
		j++;
	}
	
	for(i = 0; i < 16; i++)
	{
		lines[currentLine][i] = newLine[i];
		newLine[i] = ' ';
	}

	currentLine++;
		
	return len;
}

static long ioctlDevice(struct file *filp, unsigned int cmd, unsigned long param)
{
	int remainingGuesses = mmind_max_guesses - currentGuess;
	int newSecret = 1111;
	int i;
	
	for(i = 0; i < 5; i++) mmind_newNumber[i] = 'x';
	
	switch(cmd)
	{
		case MMIND_REMAINING:
			printk(KERN_WARNING "Remaining Called");
			copy_to_user((int32_t*) param, &remainingGuesses, sizeof(remainingGuesses));
			break;
		case MMIND_ENDGAME:
			printk(KERN_WARNING "End Game Called");
			endGame();
			break;
		case MMIND_NEWGAME:
			copy_from_user(&newSecret ,(int32_t*) param, sizeof(newSecret));
			
			sprintf(mmind_newNumber, "%d", newSecret);
			printk(KERN_WARNING "New Secret: %s\n", mmind_newNumber);
			isNewGame = 1;
			endGame();
			break;
		default:
			break;
	}
	return 0;
}

static int closeDevice(struct inode *inod,struct file *fil)
{
	printk(KERN_WARNING "Device closed...\n");
	return 0;
}

static void endGame()
{
	int i, j;
	for(i = 0; i < currentGuess; i++)
	{
		for(j = 0; j < 16; j++)
		{
			lines[i][j] = ' ';
		}
	}
	currentGuess = 0;
	currentLine = 0;
}

module_init(mm_init);
module_exit(mm_exit);
