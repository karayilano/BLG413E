cd build
cmake ..
make
./fuse /home/ahmetcicekci/Desktop/fusetest1 /home/ahmetcicekci/Desktop/fusetest2
