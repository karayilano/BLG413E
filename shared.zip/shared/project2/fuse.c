#define FUSE_USE_VERSION 26

static const char* rofsVersion = "2008.09.24";

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/xattr.h>
#include <dirent.h>
#include <unistd.h>
#include <fuse.h>
#include <magic.h>
#include <ansilove.h>

char *source_path;

static char* getPath(const char* path)
{
    char *rPath= malloc(sizeof(char)*(strlen(path)+strlen(source_path)+1));

    strcpy(rPath, source_path);
    if (rPath[strlen(rPath)-1]=='/') {
        rPath[strlen(rPath)-1]='\0';
    }
    strcat(rPath,path);

    if (strstr(rPath, ".png") != NULL)
    {
        rPath[strlen(rPath)-4] = '\0';
    }

    return rPath;
}

static int f_getattr(const char *path, struct stat *st_data)
{
    int res;
    char *upath = getPath(path);

    res = lstat(upath, st_data);
    free(upath);
    if(res == -1) {
        return -errno;
    }
    return 0;
}

static int f_readdir(const char *path, void *buf, fuse_fill_dir_t filler,off_t offset, struct fuse_file_info *fi)
{
    DIR *dp;
    struct dirent *de;
    int res;

    (void) offset;
    (void) fi;

    char *upath = getPath(path);

    dp = opendir(upath);
    if(dp == NULL) {
        res = -errno;
        return res;
    }

    while((de = readdir(dp)) != NULL) {
        struct stat st;
        memset(&st, 0, sizeof(st));
        st.st_ino = de->d_ino;
        st.st_mode = de->d_type << 12;

        char actual_file[256] = "";
        strcat(actual_file, upath);  
        if (path[strlen(path) - 1] != "/")      
        {
            strcat(actual_file, "/"); 
        }
        strcat(actual_file, de->d_name); 


        const char *magic_full;
        magic_t magic_cookie = magic_open(MAGIC_MIME_TYPE);
        if(magic_load(magic_cookie, NULL))
        {
            magic_close(magic_cookie);
            continue;
        } 

        magic_full = magic_file(magic_cookie, actual_file);
        char mtype[100] = ""; 
        sprintf(mtype, "%s", magic_full); 

    
        magic_close(magic_cookie);


        if (strcmp(mtype, "text/plain") == 0)
        {
            strcat(de->d_name, ".png"); /* source'tan erişim sağlayabilmek için uzantıları silmiyoruz, sonuna png ekliyoruz. */
            if (filler(buf, de->d_name, &st, 0))
                break;
        }
        if ((strcmp(mtype, "application/octet-stream") == 0))
        {
            strcat(de->d_name, ".png");
            if (filler(buf, de->d_name, &st, 0))
                break;
        }
        else if (strcmp(mtype, "inode/directory") == 0)
        {
            if (filler(buf, de->d_name, &st, 0))
                break;
        }
    }

    free(upath);
    closedir(dp);
    return 0;
}

static int f_open(const char *path, struct fuse_file_info *finfo)
{
    int res;
    int flags = finfo->flags;

    if ((flags & O_WRONLY) || (flags & O_RDWR) || (flags & O_CREAT) || (flags & O_EXCL) || (flags & O_TRUNC) || (flags & O_APPEND)) {
        return -EROFS;
    }

    char *upath = getPath(path);

    res = open(upath, flags);

    free(upath);
    if(res == -1) {
        return -errno;
    }
    close(res);
    return 0;
}

static int f_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *finfo)
{

    char *upath = getPath(path);

    struct ansilove_ctx ctx;
    struct ansilove_options options;

    ansilove_init(&ctx, &options);
    ansilove_loadfile(&ctx, upath);
    ansilove_ansi(&ctx, &options);

    memcpy(buf, ctx.png.buffer + offset, size); 

    free(upath); 

    return ctx.png.length - offset; 
}


struct fuse_operations rofs_oper = {
    .getattr     = f_getattr,
    .readdir     = f_readdir,
    .open        = f_open,
    .read        = f_read,
};
enum {
    KEY_HELP,
    KEY_VERSION,
};

static void usage(const char* progname)
{
    fprintf(stdout,
            "usage: %s readwritepath mountpoint [options]\n"
            "\n"
            "   Mounts readwritepath as a read-only mount at mountpoint\n"
            "\n"
            "general options:\n"
            "   -o opt,[opt...]     mount options\n"
            "   -h  --help          print help\n"
            "   -V  --version       print version\n"
            "\n", progname);
}

static int rofs_parse_opt(void *data, const char *arg, int key,
                          struct fuse_args *outargs)
{
    (void) data;

    switch (key)
    {
    case FUSE_OPT_KEY_NONOPT:
        if (source_path == 0)
        {
            source_path = strdup(arg);
            return 0;
        }
        else
        {
            return 1;
        }
    case FUSE_OPT_KEY_OPT:
        return 1;
    case KEY_HELP:
        usage(outargs->argv[0]);
        exit(0);
    case KEY_VERSION:
        fprintf(stdout, "ROFS version %s\n", rofsVersion);
        exit(0);
    default:
        fprintf(stderr, "see `%s -h' for usage\n", outargs->argv[0]);
        exit(1);
    }
    return 1;
}

static struct fuse_opt rofs_opts[] = {
    FUSE_OPT_KEY("-h",          KEY_HELP),
    FUSE_OPT_KEY("--help",      KEY_HELP),
    FUSE_OPT_KEY("-V",          KEY_VERSION),
    FUSE_OPT_KEY("--version",   KEY_VERSION),
    FUSE_OPT_END
};

int main(int argc, char *argv[])
{

    struct fuse_args args = FUSE_ARGS_INIT(argc, argv);
    int res;

    res = fuse_opt_parse(&args, &source_path, rofs_opts, rofs_parse_opt);


    if (res != 0)
    {
        fprintf(stderr, "Invalid arguments\n");
        fprintf(stderr, "see `%s -h' for usage\n", argv[0]);
        exit(1);
    }
    if (source_path == 0)
    {
        fprintf(stderr, "Missing readwritepath\n");
        fprintf(stderr, "see `%s -h' for usage\n", argv[0]);
        exit(1);
    }

    fuse_main(args.argc, args.argv, &rofs_oper, NULL);

    return 0;
}
